﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Psm32.Commands;

public class DeleteMotorTaskCommand : CommandBase
{
    public override void Execute(object? parameter)
    {
    }
}
