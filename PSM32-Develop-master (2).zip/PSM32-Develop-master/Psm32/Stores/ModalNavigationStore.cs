﻿/*using Psm32.ViewModels;
using System;

namespace Psm32.Stores;

public class ModalNavigationStore : NavigationStoreBase
{
    public bool IsOpen => CurrentViewModel != null;

    public void Close()
    {
        CurrentViewModel = null;
    }
}
*/