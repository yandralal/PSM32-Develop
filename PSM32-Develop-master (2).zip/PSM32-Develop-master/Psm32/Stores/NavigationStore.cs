﻿using Psm32.ViewModels;
using System;

namespace Psm32.Stores;

public class NavigationStore: NavigationStoreBase
{
}
