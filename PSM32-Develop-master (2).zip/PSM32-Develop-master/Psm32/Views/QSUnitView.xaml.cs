﻿using Psm32.ViewModels;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Psm32.CustomControls
{
    /// <summary>
    /// Interaction logic for QSUnit.xaml
    /// </summary>
    public partial class QSUnitView : UserControl
    {
        public QSUnitView()
        {
            InitializeComponent();
        }
    }
}
