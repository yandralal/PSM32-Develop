## Database

Database implementation uses Entity Framework

### Create Migration

In Package Manager Console run:

```
add-migration <migration name>
```

